/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package projek;

import java.awt.Component;
import java.awt.Image;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import java.nio.file.Files;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import java.io.File;

public class admin extends javax.swing.JFrame {

    Connection conn;
    private DefaultTableModel fashion;
    private DefaultTableModel Style;
    private byte[] gambarBytes = null; 
    public admin() {
        initComponents();
        
        conn = koneksi.getConnection();
        loadcbstyle();
        fashion = new DefaultTableModel();
        tbl_fashion.setModel(fashion);  
        fashion.addColumn("id_fashion");
        fashion.addColumn("kode");
        fashion.addColumn("style");
        fashion.addColumn("kategori");
        fashion.addColumn("deskripsi");
        fashion.addColumn("gambar");
        
        Style = new DefaultTableModel();
        tbl_style.setModel(Style);  
        Style.addColumn("id_style");
        Style.addColumn("nama");
        Style.addColumn("konsep");

        
        loadDatastyle();
        loadDatafashion();
    }
    
     
private void loadDatafashion() {
    fashion.setRowCount(0);
    try {
        String sql = "SELECT * FROM fashion";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            // Ambil data dari database
            int id = rs.getInt("id_fashion");
            String kode = rs.getString("kode");
            String style = rs.getString("id_style");
            String kategori = rs.getString("kategori");
            String deskripsi = rs.getString("deskripsi");
            byte[] gambarBytes = rs.getBytes("gambar");  // Membaca gambar sebagai byte[]

            // Mengonversi byte[] ke ImageIcon
            ImageIcon imageIcon = null;
            if (gambarBytes != null) {
                imageIcon = new ImageIcon(gambarBytes);  // Membuat ImageIcon dari byte array
            }

            // Menambahkan baris ke dalam model tabel
            fashion.addRow(new Object[]{
                id, 
                kode, 
                style,
                kategori,  
                deskripsi, 
                imageIcon  // Menyimpan ImageIcon ke kolom gambar
            });
        }
    } catch (SQLException e) {
        System.out.println("Error Load Data: " + e.getMessage());
    }
    ImageResizer.setImageRenderer(tbl_fashion);
}

 private void loadDatastyle() {
       Style.setRowCount(0);
    try {
        String sql = "SELECT * FROM style";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet pr = ps.executeQuery();
        while (pr.next()) {
           // Menambahkan baris ke dalam model tabel
           Style.addRow(new Object[]{
           pr.getInt("id_style"),
           pr.getString("nama"),
           pr.getString("konsep")
         });
        }
    } catch (SQLException e) {
       System.out.println("Error Save Data" + e.getMessage());
     }
  } 

public class ImageResizer {

    // Fungsi untuk resize ImageIcon
    public static ImageIcon resizeImageIcon(ImageIcon originalIcon, int targetWidth, int targetHeight) {
        Image originalImage = originalIcon.getImage();
        Image resizedImage = originalImage.getScaledInstance(targetWidth, targetHeight, Image.SCALE_SMOOTH);
        return new ImageIcon(resizedImage);
    }

    // Fungsi untuk mengatur ImageRenderer di tabel
    public static void setImageRenderer(JTable table) {
        table.getColumnModel().getColumn(5).setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                if (value instanceof ImageIcon) {
                    // Resize ImageIcon sebelum ditampilkan
                    ImageIcon resizedIcon = resizeImageIcon((ImageIcon) value, 100, 100); // Atur ukuran yang diinginkan
                    JLabel label = new JLabel(resizedIcon);
                    label.setHorizontalAlignment(JLabel.CENTER);
                    return label;
                }
                return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            }
        });
    }
}

    private void simpan(){
        try {
            if (tfid.getText().isEmpty() || tfkode.getText().isEmpty() || tfkategori.getText().isEmpty() || desk.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Semua kolom harus diisi!", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                // Ambil id_style yang dipilih
                int idStyle = getSelectedStyleId(); 
                // Periksa jika id_style valid
                if (idStyle == -1) {
                    JOptionPane.showMessageDialog(this, "Pilih style yang valid!", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    // Menyiapkan query untuk menyimpan data fashion
                    String sql = "INSERT INTO fashion (id_fashion, kode, kategori, id_style, deskripsi, gambar) VALUES (?, ?, ?, ?, ?, ?)";
                    PreparedStatement ps = conn.prepareStatement(sql);

                    // Mengisi parameter prepared statement dengan data dari form
                    ps.setString(1, tfid.getText());
                    ps.setString(2, tfkode.getText());
                    ps.setString(3, tfkategori.getText());
                    ps.setInt(4, idStyle);
                    ps.setString(5, desk.getText());

                    // Mengecek apakah gambar dipilih
                    if (gambarBytes != null) {
                        ps.setBytes(6, gambarBytes);  // Menyimpan byte array gambar
                    } else {
                        ps.setNull(6, java.sql.Types.BLOB);  // Jika gambar tidak dipilih, simpan NULL
                    }

                    // Eksekusi query untuk menyimpan data ke database
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(this, "Data saved successfully");
                    loadDatafashion(); // Memuat ulang data setelah penyimpanan berhasil
                }
            }
        } catch (SQLException e) {
            System.out.println("Error Save Data: " + e.getMessage());
        }
    }
    private void edit() {
    try {
        if (tfkode.getText().isEmpty() || tfkategori.getText().isEmpty() || desk.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Semua field harus diisi!", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            String sql = "UPDATE fashion SET kode = ?, kategori = ?, id_style = ?, deskripsi = ?, gambar = ? WHERE id_fashion = ?";
            PreparedStatement ps = conn.prepareStatement(sql);

            // Set data untuk kolom selain gambar
            ps.setString(1, tfkode.getText());
            ps.setString(2, tfkategori.getText());
            ps.setInt(3, getSelectedStyleId());
            ps.setString(4, desk.getText());

            // Menambahkan gambar jika ada gambar baru
            if (gambarBytes != null) {
                ps.setBytes(5, gambarBytes); // Menyimpan gambar sebagai byte array
            } else {
                ps.setNull(5, java.sql.Types.BLOB); // Mengatur gambar menjadi NULL jika tidak ada gambar
            }
            // Set ID untuk where clause
            ps.setInt(6, Integer.parseInt(tfid.getText()));

            // Eksekusi update query
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Data updated successfully");
            loadDatafashion();
        }
    } catch (SQLException e) {
        System.out.println("Error Save Data: " + e.getMessage());
    }
} 
//private void edit() {
//    try {
//        // Cek jika ada field yang kosong
//        if (tfkode.getText().isEmpty() || tfkategori.getText().isEmpty() || desk.getText().isEmpty()) {
//            JOptionPane.showMessageDialog(this, "Semua field harus diisi!", "Error", JOptionPane.ERROR_MESSAGE);
//        } else {
//            // Ambil ID yang akan diupdate
//            int idFashion = Integer.parseInt(tfid.getText());
//            System.out.println("Editing data with ID: " + idFashion);  // Debugging ID yang akan diupdate
//
//            // Query untuk mengupdate data
//            String sql = "UPDATE fashion SET kode = ?, kategori = ?, id_style = ?, deskripsi = ?, gambar = ? WHERE id_fashion = ?";
//            PreparedStatement ps = conn.prepareStatement(sql);
//
//            // Set data untuk kolom selain gambar
//            ps.setString(1, tfkode.getText());
//            ps.setString(2, tfkategori.getText());
//            ps.setInt(3, getSelectedStyleId());  // Pastikan ini mengembalikan ID style yang benar
//            ps.setString(4, desk.getText());
//
//            // Debugging untuk memastikan data yang dikirim
//            System.out.println("Kode: " + tfkode.getText());
//            System.out.println("Kategori: " + tfkategori.getText());
//            System.out.println("ID Style: " + getSelectedStyleId());
//            System.out.println("Deskripsi: " + desk.getText());
//
//            // Menambahkan gambar jika ada gambar baru
//            if (gambarBytes != null) {
//                ps.setBytes(5, gambarBytes);  // Menyimpan gambar sebagai byte array
//                System.out.println("Gambar baru akan disimpan.");
//            } else {
//                ps.setNull(5, java.sql.Types.BLOB);  // Mengatur gambar menjadi NULL jika tidak ada gambar
//                System.out.println("Tidak ada gambar baru.");
//            }
//
//            // Set ID untuk where clause
//            ps.setInt(6, idFashion);  // ID yang diupdate
//
//            // Eksekusi update query
//            int affectedRows = ps.executeUpdate();
//            System.out.println("Rows affected: " + affectedRows);  // Debugging jumlah baris yang terpengaruh
//
//            if (affectedRows == 0) {
//                // Jika tidak ada baris yang terpengaruh (tidak ada perubahan)
//                JOptionPane.showMessageDialog(this, "No changes made. Data is the same.", "Info", JOptionPane.INFORMATION_MESSAGE);
//            } else {
//                // Jika data berhasil diupdate
//                JOptionPane.showMessageDialog(this, "Data updated successfully");
//                loadDatafashion();  // Reload data setelah update
//            }
//        }
//    } catch (SQLException e) {
//        // Menampilkan error jika ada masalah
//        System.out.println("Error Save Data: " + e.getMessage());
//        JOptionPane.showMessageDialog(this, "Failed to update data.", "Error", JOptionPane.ERROR_MESSAGE);
//    }
//}


  
    private void hapus(){
        try  {
            int confirm = JOptionPane.showConfirmDialog(this, "Apakah Anda yakin ingin menghapus data transaksi ini?", "Konfirmasi Hapus", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
            String sql = "DELETE FROM fashion WHERE id_fashion = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, Integer.parseInt(tfid.getText()));
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data deleted successfully");
            loadDatafashion();
            }else {
                JOptionPane.showMessageDialog(this, "Tidak ada data yang diperbarui. Pastikan ID Karyawan dan Proyek benar.","Delete Error", JOptionPane.WARNING_MESSAGE);
            }
        } catch (SQLException e) {
            System.out.println("Error Save Data" + e.getMessage());
        }
    }
    
    private void simpanstyle(){
       try {
            if (idstyle.getText().isEmpty() || nstyle.getText().isEmpty() || asal.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Semua kolom harus diisi!", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                // Query untuk memeriksa apakah nama style sudah ada
                String checkStyleQuery = "SELECT * FROM style WHERE nama=?";
                PreparedStatement checkPs = conn.prepareStatement(checkStyleQuery);
                checkPs.setString(1, nstyle.getText()); // nstyle adalah JTextField untuk input nama style
                ResultSet rs = checkPs.executeQuery();

                if (rs.next()) {
                    // Jika style sudah ada di database
                    JOptionPane.showMessageDialog(this, "Style sudah terdaftar di database!", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    // Jika style belum ada, lanjutkan ke proses penyimpanan data baru
                    String sql = "INSERT INTO style (id_style, nama, konsep) VALUES (?, ?, ?)";
                    PreparedStatement ps = conn.prepareStatement(sql);
                    ps.setString(1, idstyle.getText()); // idstyle adalah JTextField untuk input id style
                    ps.setString(2, nstyle.getText());  // nstyle adalah JTextField untuk input nama style
                    ps.setString(3, asal.getText());    // asal adalah JTextField untuk input asal inspirasi
                    
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(this, "Data berhasil disimpan!");
                    loadDatastyle();
                    loadcbstyle(); // Memuat ulang combo box setelah data disimpan
                }
            }
        } catch (SQLException e) {
            System.out.println("Error Save Data: " + e.getMessage());
        }
    }
    
    private void editstyle(){
       try {
            if (nstyle.getText().isEmpty() || asal.getText().isEmpty() || idstyle.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Semua kolom harus diisi!", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                // Validasi untuk memastikan nama style belum terdaftar di database
                String checkStyleQuery = "SELECT * FROM style WHERE nama = ? AND id_style != ?";
                PreparedStatement checkPs = conn.prepareStatement(checkStyleQuery);
                checkPs.setString(1, nstyle.getText());  // nstyle adalah JTextField untuk input nama style
                checkPs.setInt(2, Integer.parseInt(idstyle.getText()));  // idstyle adalah JTextField untuk input id style
                ResultSet rs = checkPs.executeQuery();

                if (rs.next()) {
                    // Jika nama style sudah ada di database
                    JOptionPane.showMessageDialog(this, "Nama style sudah terdaftar di database!", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    // Jika tidak ada style dengan nama yang sama, lanjutkan update data
                    String sql = "UPDATE style SET nama = ?, asalinspirasi = ? WHERE id_style = ?";
                    PreparedStatement ps = conn.prepareStatement(sql);
                    ps.setString(1, nstyle.getText());  // nstyle adalah JTextField untuk input nama style
                    ps.setString(2, asal.getText());    // asal adalah JTextField untuk input asal inspirasi
                    ps.setInt(3, Integer.parseInt(idstyle.getText()));  // idstyle adalah JTextField untuk input id style
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(this, "Data berhasil diperbarui!");
                    loadDatastyle(); // Memuat ulang data setelah update
                }
            }
        } catch (SQLException e) {
            System.out.println("Error Update Data: " + e.getMessage());
        }

    }
    
    private void hapusstyle(){
        try  {
            int confirm = JOptionPane.showConfirmDialog(this, "Apakah Anda yakin ingin menghapus data transaksi ini?", "Konfirmasi Hapus", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
            String sql = "DELETE FROM style WHERE id_style = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, Integer.parseInt(idstyle.getText()));
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data deleted successfully");
            loadDatastyle();
            }else {
            JOptionPane.showMessageDialog(this, "Tidak ada data yang diperbarui. Pastikan ID Karyawan dan Proyek benar.","Delete Error", JOptionPane.WARNING_MESSAGE);
            }
        } catch (SQLException e) {
          System.out.println("Error Save Data" + e.getMessage());
        }
    }
    
    private void loadcbstyle() {
    cbstyle.removeAllItems();
    try {
        String sql = "SELECT  id_style, nama FROM style";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            String tampilan = String.format("ID: %d - %s", 
                rs.getInt("id_style"),
                rs.getString("nama")
            );
            cbstyle.addItem(tampilan);
        }
    } catch (SQLException e) {
        System.out.println("Kesalahan Memuat Data Karyawan: " + e.getMessage());
    }
} 

private int getSelectedStyleId() {
    // Mendapatkan teks item yang dipilih dari ComboBox
    String selectedItem = (String) cbstyle.getSelectedItem();   
    // Memeriksa apakah ada item yang dipilih
    if (selectedItem == null || selectedItem.isEmpty()) {
        return -1;  // Mengembalikan -1 jika tidak ada pilihan
    }
    // Mengambil nama style dari teks item yang dipilih (contoh: "ID: 1 - Casual" -> "Casual")
    String[] parts = selectedItem.split(" - ");
    if (parts.length < 2) {
        return -1;
    }
    String styleName = parts[1];  // Nama style setelah " - "
    try {
        // Query SQL untuk mengambil id_style berdasarkan nama style
        String sql = "SELECT id_style FROM style WHERE nama = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, styleName);  // Menggunakan nama style sebagai parameter

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            return rs.getInt("id_style");  // Mengembalikan id_style jika ditemukan
        } else {
            return -1;  // Jika tidak ditemukan, mengembalikan -1
        }

    } catch (SQLException e) {
        System.out.println("Kesalahan dalam mengambil ID Style: " + e.getMessage());
        return -1;  // Jika ada kesalahan, mengembalikan -1
    }
}// Ambil ID dari model karyawan


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        idstyle = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        nstyle = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        asal = new javax.swing.JTextField();
        estyle = new javax.swing.JButton();
        hstyle = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_style = new javax.swing.JTable();
        jLabel11 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_fashion = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        tfkode = new javax.swing.JTextField();
        tfkategori = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        lbgambar = new javax.swing.JLabel();
        inptgambar = new javax.swing.JButton();
        imgpath = new javax.swing.JTextField();
        tfid = new javax.swing.JTextField();
        simpan = new javax.swing.JButton();
        edit = new javax.swing.JButton();
        hapus = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        desk = new javax.swing.JTextArea();
        cbstyle = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTabbedPane1.setBackground(new java.awt.Color(251, 251, 251));

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(255, 221, 174));
        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel2.setFont(new java.awt.Font("Script MT Bold", 0, 48)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(224, 123, 57));
        jLabel2.setText("style pakaian");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(165, 165, 165)
                .addComponent(jLabel2)
                .addContainerGap(168, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        jPanel2.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 600, -1));

        jPanel4.setBackground(new java.awt.Color(212, 246, 255));
        jPanel4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(51, 102, 255), new java.awt.Color(0, 0, 0), null, new java.awt.Color(0, 204, 204)));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel5.setBackground(new java.awt.Color(198, 231, 255));
        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 255)));

        jLabel8.setText("id");

        jLabel9.setText("style / tema :");

        jLabel10.setText("asa inspirasi :");

        estyle.setText("edit");
        estyle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                estyleActionPerformed(evt);
            }
        });

        hstyle.setText("hapus");
        hstyle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hstyleActionPerformed(evt);
            }
        });

        jButton3.setText("simpan");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        tbl_style.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3"
            }
        ));
        tbl_style.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_styleMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tbl_style);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 390, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31))
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(idstyle, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton3))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(nstyle, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(hstyle))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10)
                            .addComponent(asal, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(estyle)))
                .addGap(70, 70, 70))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(idstyle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel9)
                .addGap(4, 4, 4)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nstyle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(hstyle))
                .addGap(12, 12, 12)
                .addComponent(jLabel10)
                .addGap(5, 5, 5)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(asal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(estyle))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 17, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
        );

        jPanel4.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 20, 450, 470));

        jLabel11.setText("jLabel11");
        jPanel4.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(23, 30, 560, 270));

        jPanel2.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 87, 600, 530));

        jTabbedPane1.addTab("tab1", jPanel2);

        jPanel1.setBackground(new java.awt.Color(212, 246, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setText("kode :");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 110, -1, -1));

        tbl_fashion.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tbl_fashion.setRowHeight(100);
        tbl_fashion.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_fashionMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_fashion);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(29, 385, 553, 224));

        jLabel3.setText("style :");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 160, -1, -1));

        jLabel4.setText("deskripsi :");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 258, -1, -1));

        tfkode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfkodeActionPerformed(evt);
            }
        });
        jPanel1.add(tfkode, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 130, 251, -1));

        tfkategori.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfkategoriActionPerformed(evt);
            }
        });
        jPanel1.add(tfkategori, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 230, 251, -1));

        jLabel5.setText("gambar :");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 60, -1, -1));

        lbgambar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(lbgambar, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 90, 134, 141));

        inptgambar.setText("pilih");
        inptgambar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inptgambarActionPerformed(evt);
            }
        });
        jPanel1.add(inptgambar, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 260, 61, -1));

        imgpath.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                imgpathActionPerformed(evt);
            }
        });
        jPanel1.add(imgpath, new org.netbeans.lib.awtextra.AbsoluteConstraints(318, 260, 160, -1));
        jPanel1.add(tfid, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 80, 251, -1));

        simpan.setText("simpan");
        simpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                simpanActionPerformed(evt);
            }
        });
        jPanel1.add(simpan, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 310, -1, -1));

        edit.setText("edit");
        edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editActionPerformed(evt);
            }
        });
        jPanel1.add(edit, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 310, -1, -1));

        hapus.setText("hapus");
        hapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hapusActionPerformed(evt);
            }
        });
        jPanel1.add(hapus, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 310, -1, -1));

        jLabel6.setText("id :");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 60, -1, -1));

        jLabel7.setText("kategori :");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 210, -1, -1));

        desk.setColumns(20);
        desk.setRows(5);
        jScrollPane3.setViewportView(desk);

        jPanel1.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 280, 251, -1));

        cbstyle.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbstyle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbstyleActionPerformed(evt);
            }
        });
        jPanel1.add(cbstyle, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, 251, -1));

        jTabbedPane1.addTab("tab2", jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void cbstyleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbstyleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbstyleActionPerformed

    private void hapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hapusActionPerformed
        // TODO add your handling code here:
        hapus();
    }//GEN-LAST:event_hapusActionPerformed

    private void editActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editActionPerformed
        // TODO add your handling code here:
        edit();
    }//GEN-LAST:event_editActionPerformed

    private void simpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_simpanActionPerformed
        // TODO add your handling code here:
        simpan();
    }//GEN-LAST:event_simpanActionPerformed

    private void imgpathActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_imgpathActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_imgpathActionPerformed

    private void inptgambarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inptgambarActionPerformed
        // TODO add your handling code here:
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
        FileNameExtensionFilter filter = new FileNameExtensionFilter("*.IMAGE","JPG","gif","png");
        fileChooser.addChoosableFileFilter(filter);
        int result = fileChooser.showSaveDialog(null);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            String path = selectedFile.getAbsolutePath();
            imgpath.setText(path);

            try {
                gambarBytes = Files.readAllBytes(selectedFile.toPath());
                ImageIcon imageIcon = new ImageIcon(gambarBytes);

                int labelWidth = 200;
                int labelHeight =200;

                int imageWidth = imageIcon.getIconWidth();
                int imageHeight = imageIcon.getIconHeight();

                double scaleX = (double) labelWidth / (double) imageWidth;
                double scaleY = (double) labelHeight / (double) imageHeight;
                double scale = Math.min(scaleX,scaleY);

                Image scaledImage = imageIcon.getImage().getScaledInstance((int) (scale * imageWidth), (int) (scale * imageHeight), Image.SCALE_SMOOTH);

                lbgambar.setIcon(new ImageIcon(scaledImage));
            } catch (Exception e) {
                System.out.println("Error " + e.getMessage());
            }
        }
    }//GEN-LAST:event_inptgambarActionPerformed

    private void tfkategoriActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfkategoriActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfkategoriActionPerformed

    private void tfkodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfkodeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfkodeActionPerformed

    private void tbl_fashionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_fashionMouseClicked
        // TODO add your handling code here:
        int tabel = tbl_fashion.getSelectedRow();

        // Mengambil data dari tabel
        tfid.setText(tbl_fashion.getValueAt(tabel, 0).toString());
        tfkode.setText(tbl_fashion.getValueAt(tabel, 1).toString());
        String styleId = tbl_fashion.getValueAt(tabel, 2).toString();  // Mengambil ID style dari kolom style di tabel
        tfkategori.setText(tbl_fashion.getValueAt(tabel, 3).toString());
        desk.setText(tbl_fashion.getValueAt(tabel, 4).toString()); // Menambahkan deskripsi

        // Mencari item yang sesuai di ComboBox berdasarkan ID style
        for (int i = 0; i < cbstyle.getItemCount(); i++) {
            String item = cbstyle.getItemAt(i);

            // Mengecek apakah ID di ComboBox sama dengan ID style yang dipilih
            if (item.startsWith("ID: " + styleId + " -")) {
                cbstyle.setSelectedIndex(i);  // Pilih item yang sesuai
                break;
            }
        }

        // Mengambil gambar dari kolom gambar (ImageIcon) di tabel
        ImageIcon selectedImageIcon = (ImageIcon) tbl_fashion.getValueAt(tabel, 5); // Mengambil ImageIcon dari kolom gambar
        if (selectedImageIcon != null) {
            // Menampilkan gambar di JLabel
            lbgambar.setIcon(selectedImageIcon);
        }

    }//GEN-LAST:event_tbl_fashionMouseClicked

    private void tbl_styleMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_styleMouseClicked
        // TODO add your handling code here:
        int tabel = tbl_style.getSelectedRow();
        idstyle.setText(tbl_style.getValueAt(tabel, 0).toString());
        nstyle.setText(tbl_style.getValueAt(tabel, 1).toString());
        asal.setText(tbl_style.getValueAt(tabel, 2).toString());
    }//GEN-LAST:event_tbl_styleMouseClicked

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        simpanstyle();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void estyleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_estyleActionPerformed
        // TODO add your handling code here:
        editstyle();
    }//GEN-LAST:event_estyleActionPerformed

    private void hstyleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hstyleActionPerformed
        // TODO add your handling code here:
        hapusstyle();
    }//GEN-LAST:event_hstyleActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new admin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField asal;
    private javax.swing.JComboBox<String> cbstyle;
    private javax.swing.JTextArea desk;
    private javax.swing.JButton edit;
    private javax.swing.JButton estyle;
    private javax.swing.JButton hapus;
    private javax.swing.JButton hstyle;
    private javax.swing.JTextField idstyle;
    private javax.swing.JTextField imgpath;
    private javax.swing.JButton inptgambar;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel lbgambar;
    private javax.swing.JTextField nstyle;
    private javax.swing.JButton simpan;
    private javax.swing.JTable tbl_fashion;
    private javax.swing.JTable tbl_style;
    private javax.swing.JTextField tfid;
    private javax.swing.JTextField tfkategori;
    private javax.swing.JTextField tfkode;
    // End of variables declaration//GEN-END:variables
}
