/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package projek;

import java.awt.Component;
import java.awt.Dimension;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

public class user extends javax.swing.JFrame {

    Connection conn;
    public user() {
        initComponents();
        conn = koneksi.getConnection();
       // Mengubah model tabel untuk memiliki dua kolom: satu untuk gambar dan satu untuk deskripsi
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Kode");
        model.addColumn("Gambar");  // Kolom pertama untuk gambar
        model.addColumn("Deskripsi");  // Kolom kedua untuk deskripsi
        model.addColumn("Ulasan");
        model.addColumn("rating");
        pakaian.setModel(model);


        loadFashionData();
        loadKategoriComboBox();
        loadStyleComboBox();

    }
private void loadKategoriComboBox() {
    cbkategori.removeAllItems();
    try {
        String sql = "SELECT kategori FROM fashion";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            String tampilan = rs.getString("kategori");
            cbkategori.addItem(tampilan);
        }
    } catch (SQLException e) {
        System.out.println("Error loading kategori: " + e.getMessage());
    }
}

private void loadStyleComboBox() {
    cbstyle.removeAllItems();
    try {
        String sql = "SELECT id_style, nama FROM style";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            String tampilan = rs.getString("nama");
            cbstyle.addItem(tampilan);
        }
    } catch (SQLException e) {
        System.out.println("Error loading style: " + e.getMessage());
    }
}
private void loadFashionData() {
    DefaultTableModel model = (DefaultTableModel) pakaian.getModel();
    model.setRowCount(0); // Bersihkan data tabel sebelumnya

    try {
        // Query untuk memuat semua data fashion tanpa filter
        String sql = "SELECT f.kode, f.gambar, f.deskripsi, " +
                     "COALESCE(u.komentar, '') AS komentar, " +
                     "COALESCE(AVG(u.rating), 0) AS rata_rating " +  
                     "FROM fashion f " +
                     "LEFT JOIN ulasan u ON f.id_fashion = u.id_fashion " +  
                     "GROUP BY f.kode, f.gambar, f.deskripsi " +  
                     "ORDER BY MAX(u.tanggal) DESC";  

        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            String kode = rs.getString("kode");
            byte[] imgBytes = rs.getBytes("gambar");
            String deskripsi = rs.getString("deskripsi");
            String komentar = rs.getString("komentar");  
            double rataRating = rs.getDouble("rata_rating");  

            ImageIcon imageIcon = null;
            if (imgBytes != null) {
                imageIcon = new ImageIcon(imgBytes);
                java.awt.Image img = imageIcon.getImage();
                java.awt.Image scaledImg = img.getScaledInstance(50, 50, java.awt.Image.SCALE_SMOOTH);
                imageIcon = new ImageIcon(scaledImg);
            }

            // Menambahkan gambar, deskripsi, komentar, dan rata-rata rating ke dalam model tabel
            model.addRow(new Object[]{kode, imageIcon, deskripsi, komentar, rataRating});
        }

        // Menetapkan renderer untuk kolom gambar
        if (pakaian.getColumnModel().getColumnCount() > 1) {
            pakaian.getColumnModel().getColumn(1).setCellRenderer(new ImageRenderer());
        }

    } catch (SQLException e) {
        System.out.println("Error loading all fashion data: " + e.getMessage());
    }
}

private void Filter() {
    String selectedKategori = (String) cbkategori.getSelectedItem();
    String selectedStyle = (String) cbstyle.getSelectedItem();

    DefaultTableModel model = (DefaultTableModel) pakaian.getModel();
    model.setRowCount(0); // Bersihkan data tabel sebelumnya

    try {
        // Mengubah SQL untuk menambahkan rating dan komentar dari tabel ulasan
        String sql = "SELECT f.kode, f.gambar, f.deskripsi, " +
                     "COALESCE(u.komentar, '') AS komentar, " +
                     "COALESCE(AVG(u.rating), 0) AS rata_rating " +  // Menghitung rata-rata rating
                     "FROM fashion f " +
                     "JOIN style s ON f.id_style = s.id_style " +
                     "LEFT JOIN ulasan u ON f.id_fashion = u.id_fashion " +  // Menggunakan LEFT JOIN dengan ulasan
                     "WHERE f.kategori = ? AND s.nama = ? " +
                     "GROUP BY f.kode, f.gambar, f.deskripsi " +  // Mengelompokkan berdasarkan kode fashion
                     "ORDER BY MAX(u.tanggal) DESC";  // Menampilkan ulasan terbaru berdasarkan tanggal

        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, selectedKategori);
        ps.setString(2, selectedStyle);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            String kode = rs.getString("kode");
            byte[] imgBytes = rs.getBytes("gambar");
            String deskripsi = rs.getString("deskripsi");
            String komentar = rs.getString("komentar");  // Mendapatkan komentar terbaru
            double rataRating = rs.getDouble("rata_rating");  // Mendapatkan rata-rata rating

            // Mengatur gambar dengan ukuran tertentu
            ImageIcon imageIcon = null;
            if (imgBytes != null) {
                imageIcon = new ImageIcon(imgBytes);
                java.awt.Image img = imageIcon.getImage();
                java.awt.Image scaledImg = img.getScaledInstance(50, 50, java.awt.Image.SCALE_SMOOTH);
                imageIcon = new ImageIcon(scaledImg);
            }

            // Menambahkan gambar, deskripsi, komentar, dan rata-rata rating ke dalam model tabel
            model.addRow(new Object[]{kode, imageIcon, deskripsi, komentar, rataRating});
        }

        // Menetapkan renderer untuk kolom gambar
        if (pakaian.getColumnModel().getColumnCount() > 1) {
            pakaian.getColumnModel().getColumn(1).setCellRenderer(new ImageRenderer());
        }

    } catch (SQLException e) {
        System.out.println("Error loading filtered fashion data: " + e.getMessage());
    }
}


    public class ImageRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,boolean hasFocus, int row, int column) {
            if (value instanceof ImageIcon) {
                setIcon((ImageIcon) value);
                setText(null);
            } else {
                setIcon(null);
                setText(value != null ? value.toString() : "");
            }
            return this;
        }
    }

   // Fungsi untuk mengambil semua ulasan dari produk berdasarkan baris yang dipilih
   private String getAllUlasanForProduct(String kodePakaian) {
    StringBuilder ulasanBuilder = new StringBuilder();

    try {
        // Langkah pertama: Ambil id_fashion berdasarkan kode pakaian
        String idFashionQuery = "SELECT id_fashion FROM fashion WHERE kode = ?";
        PreparedStatement ps1 = conn.prepareStatement(idFashionQuery);
        ps1.setString(1, kodePakaian);
        ResultSet rs1 = ps1.executeQuery();

        if (rs1.next()) {
            // Ambil id_fashion yang sesuai
            int idFashion = rs1.getInt("id_fashion");

            // Langkah kedua: Ambil ulasan, user, dan tanggal berdasarkan id_fashion
            String ulasanQuery = "SELECT u.komentar, l.user AS user, u.tanggal " +
                                 "FROM ulasan u " +
                                 "JOIN login l ON u.id_user = l.id_user " +  // Join dengan tabel login untuk mendapatkan username
                                 "WHERE u.id_fashion = ?";
            PreparedStatement ps2 = conn.prepareStatement(ulasanQuery);
            ps2.setInt(1, idFashion);  // Gunakan id_fashion untuk mengambil ulasan
            ResultSet rs2 = ps2.executeQuery();

            // Loop melalui hasil dan masukkan ke dalam StringBuilder
            while (rs2.next()) {
                // Ambil komentar, user, dan tanggal
                String komentar = rs2.getString("komentar");
                String user = rs2.getString("user");  // Ambil username dari tabel login
                Date tanggal = rs2.getDate("tanggal");

                // Format tanggal jika diperlukan
                SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy");
                String formattedDate = sdf.format(tanggal);

                // Gabungkan user, tanggal, dan komentar
                ulasanBuilder.append(user)
                              .append(" - ")
                              .append(formattedDate)
                              .append("\n")
                              .append("- ")
                              .append(komentar)
                              .append("\n\n");
            }
        }
    } catch (SQLException e) {
        System.out.println("Error retrieving reviews: " + e.getMessage());
    }

    return ulasanBuilder.toString();
}


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        cbkategori = new javax.swing.JComboBox<>();
        cbstyle = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btncari = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        pakaian = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(51, 255, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel4.setBackground(new java.awt.Color(255, 221, 174));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel3.setFont(new java.awt.Font("Ravie", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(224, 123, 57));
        jLabel3.setText("Ekspresikan Dirimu dengan Gaya Terbaru Kami! ");

        jLabel4.setFont(new java.awt.Font("Ravie", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(224, 123, 57));
        jLabel4.setText("Temukan Style yang Cocok untukmu Hari Ini");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(85, 85, 85)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jLabel4))
                    .addComponent(jLabel3))
                .addContainerGap(84, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 760, 100));

        jPanel2.setBackground(new java.awt.Color(212, 246, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        cbkategori.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        cbstyle.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel1.setText("kategori :");

        jLabel2.setText("style :");

        btncari.setText("cari");
        btncari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncariActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btncari)
                    .addComponent(jLabel2)
                    .addComponent(jLabel1)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(cbkategori, 0, 124, Short.MAX_VALUE)
                        .addComponent(cbstyle, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(52, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cbkategori, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(7, 7, 7)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cbstyle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33)
                .addComponent(btncari)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 100, 220, 370));

        jPanel3.setBackground(new java.awt.Color(198, 231, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        pakaian.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null},
                {null},
                {null},
                {null}
            },
            new String [] {
                "Title 1"
            }
        ));
        pakaian.setRowHeight(50);
        pakaian.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pakaianMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(pakaian);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(39, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 473, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(39, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49))
        );

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 100, 539, 370));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btncariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncariActionPerformed
        // TODO add your handling code here:
        Filter();
    }//GEN-LAST:event_btncariActionPerformed

    private void pakaianMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pakaianMouseClicked
        // TODO add your handling code here:
    int row = pakaian.rowAtPoint(evt.getPoint());  // Mendapatkan baris yang diklik
    int column = pakaian.columnAtPoint(evt.getPoint());  // Mendapatkan kolom yang diklik

    // Mengecek jika yang diklik adalah kolom yang sesuai (misalnya kolom kode produk)
    if (column == 0) {  // Asumsikan kolom pertama berisi kode pakaian
        // Mengambil kode pakaian dari kolom pertama
        String kodePakaian = (String) pakaian.getValueAt(row, 0);

        // Mengambil deskripsi dari kolom kedua
        String deskripsi = (String) pakaian.getValueAt(row, 2);

        // Mengambil semua ulasan yang terkait dengan produk pada baris yang dipilih
        String ulasan = getAllUlasanForProduct(kodePakaian);  // Menggunakan kodePakaian untuk mengambil ulasan

        // Menggabungkan deskripsi dan ulasan untuk ditampilkan dalam dialog
        StringBuilder dialogContent = new StringBuilder();
        dialogContent.append("Deskripsi:\n").append(deskripsi).append("\n\n");
        dialogContent.append("Ulasan:\n").append(ulasan.isEmpty() ? "Belum ada ulasan." : ulasan);

        // Panel untuk menampilkan deskripsi dan ulasan, serta input ulasan baru dan rating
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        // Menampilkan deskripsi produk
        JTextArea textAreaDeskripsi = new JTextArea(dialogContent.toString());
        textAreaDeskripsi.setEditable(false);
        textAreaDeskripsi.setLineWrap(true);
        textAreaDeskripsi.setWrapStyleWord(true);
        JScrollPane deskripsiScroll = new JScrollPane(textAreaDeskripsi);
        deskripsiScroll.setPreferredSize(new Dimension(380, 150));

        // Input untuk ulasan baru
        JTextArea textAreaInputUlasan = new JTextArea(5, 30);  // Area untuk mengetik ulasan baru
        JScrollPane inputUlasanScroll = new JScrollPane(textAreaInputUlasan);
        inputUlasanScroll.setPreferredSize(new Dimension(380, 100));

        // Rating dengan JComboBox
        String[] ratings = {"1", "2", "3", "4", "5"};
        JComboBox<String> ratingComboBox = new JComboBox<>(ratings);

        // Menambahkan komponen ke panel
        panel.add(deskripsiScroll);
        panel.add(new JLabel("Tambahkan ulasan baru:"));
        panel.add(inputUlasanScroll);
        panel.add(new JLabel("Pilih rating:"));
        panel.add(ratingComboBox);

        // Menampilkan dialog dengan konten
        int option = JOptionPane.showConfirmDialog(null, panel, "Deskripsi, Ulasan, dan Rating", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        // Jika pengguna menekan OK
        if (option == JOptionPane.OK_OPTION) {
            String ulasanBaru = textAreaInputUlasan.getText();
            String rating = (String) ratingComboBox.getSelectedItem();

            // Simpan ulasan baru dan rating ke database atau variabel
            saveReviewAndRating(kodePakaian, ulasanBaru, rating);

            // Tampilkan pesan sukses
            JOptionPane.showMessageDialog(null, "Ulasan dan rating berhasil disimpan!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}

// Metode untuk menyimpan ulasan dan rating ke database
private void saveReviewAndRating(String kodePakaian, String ulasanBaru, String rating) {
    // Misalnya kita memiliki ID pengguna (idUser) yang didapat dari sesi login
    String idUser = "1";  // Gantilah dengan ID user yang aktif atau sesi login Anda

    // Langkah pertama: Ambil id_fashion berdasarkan kode pakaian
    int idFashion = getIdFashionByKodePakaian(kodePakaian);
    
    if (idFashion != -1) {
        // Koneksi database
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            // Mendapatkan koneksi ke database
            conn = koneksi.getConnection();  // Pastikan ada metode untuk mendapatkan koneksi

            // SQL query untuk menyimpan ulasan dan rating
            String sql = "INSERT INTO ulasan (id_user, id_fashion, komentar, rating, tanggal) " +
                         "VALUES (?, ?, ?, ?, ?)";

            // Menyiapkan statement
            stmt = conn.prepareStatement(sql);

            // Menyeting parameter dengan nilai yang diambil dari form dan logika aplikasi
            stmt.setInt(1, Integer.parseInt(idUser));  // id_user
            stmt.setInt(2, idFashion);                  // id_fashion
            stmt.setString(3, ulasanBaru);             // komentar/ulasan baru
            stmt.setInt(4, Integer.parseInt(rating));  // rating yang dipilih
            stmt.setDate(5, new java.sql.Date(System.currentTimeMillis())); // Tanggal ulasan (sekarang)

            // Mengeksekusi query untuk menyimpan data
            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Ulasan dan rating berhasil disimpan!");
            } else {
                System.out.println("Gagal menyimpan ulasan dan rating.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    } else {
        System.out.println("Id Fashion tidak ditemukan untuk kode pakaian: " + kodePakaian);
    }
}

// Fungsi untuk mendapatkan id_fashion berdasarkan kode pakaian
private int getIdFashionByKodePakaian(String kodePakaian) {
    int idFashion = -1;  // Jika tidak ditemukan, kembalikan -1 sebagai tanda kesalahan

    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;

    try {
        // Koneksi ke database
        conn = koneksi.getConnection();

        // Query untuk mencari id_fashion berdasarkan kode pakaian
        String query = "SELECT id_fashion FROM fashion WHERE kode = ?";
        ps = conn.prepareStatement(query);
        ps.setString(1, kodePakaian);
        rs = ps.executeQuery();

        if (rs.next()) {
            idFashion = rs.getInt("id_fashion");  // Mendapatkan id_fashion
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        try {
            if (rs != null) rs.close();
            if (ps != null) ps.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    return idFashion;  // Mengembalikan id_fashion atau -1 jika tidak ditemukan
    }//GEN-LAST:event_pakaianMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(user.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(user.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(user.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(user.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new user().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btncari;
    private javax.swing.JComboBox<String> cbkategori;
    private javax.swing.JComboBox<String> cbstyle;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable pakaian;
    // End of variables declaration//GEN-END:variables
}
